export class Veiculo {
  _id: string;
  marca: string;
  nome: string;
  versao: string;
  ano: string;
  kilometragem: string;
  cor: string;
  preco: string;
  dt_atualizacao: string
}
